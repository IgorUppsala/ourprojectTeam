﻿(function ( flyingDutchman,underForeignFlag, $, document){
    underForeignFlag.OrderController= {
        // Function of items details listings
        ItemsListing() {
            underForeignFlag.Main.SetMainBodyHeight();

            const raw = window.sessionStorage.getItem('OrderItems');
            const itemsInOrder = typeof raw === 'string' && raw.length ? JSON.parse(raw) : [];
            const items = {};
            const ORDER_DB_NAME = 'orders';

            const destroyAllBtn = document.getElementById('destroy-all');
            const makeOrderBtn = document.getElementById('make-order');
            const itemsContainer = document.querySelector('.left-items-description');
            const notices = {
                empty: underForeignFlag.Main.GetTranslationText("AddSomething")
            };

            // All summarizations
            const totalElement = document.getElementById('item_price_vat');
            const quantitiesElement = document.getElementById('item_numbers');
            const cartBadge = document.querySelector('.total-qty');

            // History
            let history = [];
            let step = -1;

            // Undo Redo buttons
            const undoBtn = document.getElementById('undo');
            const redoBtn = document.getElementById('redo');

            // Modal window
            const modal = document.querySelector('.modal');
            const overlay = document.querySelector('.modal-overlay');
            const btnModalSuccess = document.getElementById('modal-success');
            const modalTitle = document.getElementById('modal-title');

            function openModal(title, successCallback) {
                // console.log('Button clicked');
                modal.classList.remove('hidden');
                overlay.classList.remove('hidden');
                modalTitle.innerText = title;

                btnModalSuccess.addEventListener('click', ($event) => {
                    $event.preventDefault();
                    closeModal();
                    successCallback();
                });
            }

            function closeModal() {
                modal.classList.add('hidden');
                overlay.classList.add('hidden');
            }

            // All summarization actions
            function updateUI() {
                let total = 0;
                let quantities = 0;

                Object.keys(items).forEach((key) => {
                    const { price, quantity, destroyed } = items[key];

                    if(destroyed) {
                        return;
                    }

                    total += (price * quantity);
                    quantities += quantity;
                });

                totalElement.innerText =
                    underForeignFlag.Main.GetTranslationText("TotalPriceInclVat")+
                    `: ${underForeignFlag.Formatter.GetFormattedCurrency(parseFloat(total))}`;
                quantitiesElement.innerText =
                    underForeignFlag.Main.GetTranslationText("NumberOfItems")+
                    `: ${quantities}`;
                cartBadge.innerHTML = quantities;

                if(quantities === 0) {
                    showItemsNotice('empty');
                    destroyAllBtn.style.display = 'none';
                    makeOrderBtn.style.display = 'none';
                } else {
                    showItemsNotice('clear');
                    destroyAllBtn.style.display = 'inline-block';
                    makeOrderBtn.style.display = 'inline-block';
                }
            }

            function onChangeQty($event, id) {
                const quantity = parseInt($event.target.value);

                items[id].quantity = quantity;
                underForeignFlag.UndoRedoManager.DoFunction(underForeignFlag.Main.AddToOrderCart(items[id].item_nr, quantity));

                updateUI();
            }

            // History
            function undo() {
                const actionStep = history[step];

                if (!actionStep) {
                    return;
                }

                actionStep.undo();
                step -= 1;

                updateButtonsState();
            }

            function redo() {
                const actionStep = history[step + 1];

                if (!actionStep) {
                    return;
                }

                actionStep.redo();
                step += 1;

                updateButtonsState();
            }

            function addToHistory(action) {
                history.splice(step + 1, history.length - step);

                history.push(action);
                step = history.length - 1;
            }

            function showItem(id) {
                const element = document.getElementById(`cart-item-${id}`);
                element.style.display = 'block';
                items[id].destroyed = false;

                underForeignFlag.UndoRedoManager.DoFunction(underForeignFlag.Main.AddToOrderCart(items[id].item_nr, items[id].quantity));
                updateUI();
            }

            function hideItem(id) {
                const element = document.getElementById(`cart-item-${id}`);
                element.style.display = 'none';
                items[id].destroyed = true;

                underForeignFlag.UndoRedoManager.DoFunction(underForeignFlag.Main.DeleteFromOrderCart([id]));
                updateUI();
            }

            function onClickDestroy(id) {
                hideItem(id);

                addToHistory({
                    undo: () => showItem(id),
                    redo: () => hideItem(id)
                });
                updateButtonsState();
            }

            function destroyAll(ids) {
                ids.forEach(id => hideItem(id));
            }

            function restoreAll(ids) {
                ids.forEach(id => showItem(id));
            }

            function onClickDestroyAll() {
                const ids = [];

                Object.keys(items).forEach((key) => {
                    const item = items[key];

                    if (!item.destroyed) {
                        ids.push(item.item_nr);
                    }
                });
                destroyAll(ids);

                addToHistory({
                    undo: () => restoreAll(ids),
                    redo: () => destroyAll(ids)
                });
                updateButtonsState();
            }

            function onClickMakeOrder() {
                const orderID = Math.random().toString(36).substring(5);
                //alert(`Order Success. OrderID: ${orderID}`);

                openModal(
                    `Order Success. OrderID: ${orderID}`,
                    () => {
                        const rawOrders = window.sessionStorage.getItem(ORDER_DB_NAME);
                        const orders = rawOrders ? JSON.parse(rawOrders) : [];

                        orders.push({ id: orderID, date: new Date().toISOString() });

                        window.sessionStorage.setItem(ORDER_DB_NAME, JSON.stringify(orders));
                        window.sessionStorage.setItem('OrderItems', JSON.stringify([]));
                        underForeignFlag.Main.RedirectUrl("Presentation");
                    }
                );
            }

            function hasUndo() {
                return step !== -1;
            }

            function hasRedo() {
                return step < (history.length - 1);
            }

            function updateButtonsState() {
                undoBtn.disabled = !hasUndo();
                redoBtn.disabled = !hasRedo();
            }

            // Info Helpers
            function showItemsNotice(notice) {
                itemsContainer.textContent = notices[notice] || '';
            }

            // DOM Documents elements
            if(itemsInOrder.length > 0) {
                // Normalize data
                itemsInOrder.forEach((raw) => {
                    const item = JSON.parse(raw);
                    const everyItem = underForeignFlag.PresentationModel.GetItemById(item.item_nr);

                    item.price = parseFloat(everyItem.priceinclvat);
                    item.quantity = parseInt(item.quantity);
                    return items[item.item_nr] = item;
                });

                // Testing code

                /*
                console.log(raw);
                const itemsReally = JSON.parse(itemsInOrder);
                console.log(raw);
                console.log(itemsReally);
                */


                //Order list: Items details. Start
                // List Headers
                document.querySelector('.it-style-left').textContent
                    = underForeignFlag.Main.GetTranslationText("ItemDetail");
                document.querySelector('.it-style-right').textContent
                    = underForeignFlag.Main.GetTranslationText("PriceInclVat") +
                    " | "
                    + underForeignFlag.Main.GetTranslationText("Quantity");

                // underForeignFlag.FlyingDutchManPresentationDB.spirits;

                // Loop for items in LocalStorage
                // Item identifier
                for(let i=0; i< itemsInOrder.length; i++) {
                    let everyUnit = JSON.parse(itemsInOrder[i]);
                    let everyItem = underForeignFlag.PresentationModel.GetItemById(everyUnit.item_nr);


                    //  Testing code

                    /*
                    console.log(everyItem);
                    console.log(everyUnit);
                    console.log(JSON.stringify(...itemsInOrder));
                    console.log(...itemsInOrder);
                    */

                    // Every new item div orders (info, price, order amount) className
                    let order = "lineInfo"+i;

                    // Common parent orders div (for info, price, order amount)
                    const divList = document.createElement('div');
                    divList.id = `cart-item-${everyUnit.item_nr}`;
                    divList.className = `${order}`;
                    if(i>0) { divList.style.borderTop = "1px dashed blue"};
                    divList.style.display = "flex";
                    //div_list.innerText = everyItem.name;
                    /* div.innerText +=  ` -- ${underForeignFlag.Main.GetTranslationText("Category")}: `;
                       div.innerText += everyItem.catgegory; */
                    document.querySelector('.items-description').appendChild(divList);


                    // List of items - Name of items divs
                    const divLeft = document.createElement('div');
                    divLeft.id = everyUnit.item_nr;
                    divLeft.className = "bev_name";
                    divLeft.innerText = everyItem.name;
                    /* div.innerText +=  ` -- ${underForeignFlag.Main.GetTranslationText("Category")}: `;
                       div.innerText += everyItem.catgegory; */
                    document.querySelector(`.${order}`).appendChild(divLeft);

                    // List of Prices divs
                    const divRight = document.createElement('div');
                    divRight.id = everyItem.name;
                    divRight.className = "price";
                    divRight.innerText = underForeignFlag.Formatter.GetFormattedCurrency(parseFloat(everyItem.priceinclvat));
                    document.querySelector(`.${order}`).appendChild(divRight);

                    // List of Inputs for amount inputs
                    const input = document.createElement('input');
                    input.className = "items-amount";
                    input.type = "number";
                    input.min = 1;
                    input.max = 100;
                    input.value = everyUnit.quantity;
                    input.onchange = ($event) => onChangeQty($event, everyUnit.item_nr);
                    document.querySelector(`.${order}`).appendChild(input);
                    console.log(input.value);

                    // Delete item divs, List of Delete icon every item
                    const divDeleteItem = document.createElement('div');
                    divDeleteItem.id = everyUnit.item_nr+" delete";
                    divDeleteItem.className = "delete_item";
                    divDeleteItem.innerHTML = "<span class=\"icon fa fa-trash delete-order fa-2x\"></span>";
                    // Send to context item_nr
                    divDeleteItem.onclick = () => onClickDestroy(everyUnit.item_nr);
                    document.querySelector(`.${order}`).appendChild(divDeleteItem);
                }
            }

            // SUMMARY Div
            document.querySelector('.it-style').textContent
                = underForeignFlag.Main.GetTranslationText("Summary");

            undoBtn.addEventListener('click', undo);
            redoBtn.addEventListener('click', redo);
            destroyAllBtn.addEventListener('click', onClickDestroyAll);
            makeOrderBtn.addEventListener('click', onClickMakeOrder);

            updateButtonsState();
            updateUI();
        },
    };
    $(function () {
        underForeignFlag.OrderController.ItemsListing();
    });
}(window.flyingDutchman = window.flyingDutchman || {}, window.underForeignFlag = window.underForeignFlag || {}, window.jQuery, document));

